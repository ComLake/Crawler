# (Crawler) Hungry Worm

<img src="https://www.ancient-origins.net/sites/default/files/field/image/Mongolian-Death-Worm.jpg" width = 400 height =250>

Automation Crawler Website, Data Analysis using JAVA and Selenium 

## Getting Started

 Development of Data Acquisition and Integration Tool for Data Lake

## Features and Detail :
* Automate crawl data from websites
* Data anlysis and set metadata for web dashbroad
 
## Target users :
For everyone 

## Prerequisites


**Download and setup JDK, Chrome**

[<img src="http://itplus-academy.edu.vn/upload/c47d9c29fc44c2b7996a2613aec3c1f9/files/writer1/jv.jpg" width = 150 height =80>](https://www.oracle.com/java/technologies/javase-jdk11-downloads.html)
[<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Google_Chrome_icon_%28September_2014%29.svg/1200px-Google_Chrome_icon_%28September_2014%29.svg.png" width = 80 height =80>](https://www.google.com/chrome/)

## Running


* ### Run tests


## Built With

* [Selenium](https://www.selenium.dev/) - Automation WebDriver
* [JAVA](https://www.java.com/en/) - Main Programming Language

## Contributing

Just a small part of the big ComLake

## Authors

* **Nguyen An Thiet** - *USTHBI8 -174* - [JeffKi11er](https://github.com/JeffKi11er) -<Fresher Java, Android>

