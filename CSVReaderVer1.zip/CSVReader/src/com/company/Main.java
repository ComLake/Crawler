package com.company;

import com.company.hungry_worm.Automation;

public class Main {
    public static void main(String[] args) {
        System.out.println("     __________\n" +
                " ___/  ______  \\_____\n" +
                "(o____/      \\___))__)");

        System.out.println("------------------------");
        Automation automation = new Automation();
//        automation.dynamicPOSTRequest("https://jsonplaceholder.typicode.com/posts");
        automation.crawl();
    }
}
